App({
  globalData: {},
  onLaunch: function () {}
});

var store = require('../../utils/store');
var P = require('../../utils/parse');

function sizeText(n){
  if(!n) return '';
  if(n < 1024) return n + ' B';
  if(n < 1048576) return Math.round(n / 1024) + ' KB';
  return (n / 1048576).toFixed(1) + ' MB';
}

Page({
  data: {
    isNew: true,
    statusList: store.STATUS_LIST,
    statusIndex: 0,
    form: { title: '', note: '', dept: '', status: '待开始', assigned: '', due: '' },
    attachments: [],
    pasteText: '',
    multiDraft: [],
    saving: false
  },

  onLoad: function (opt) {
    var id = opt && opt.id;
    if (id) {
      var t = store.getTasks().filter(function (x) { return x.id === id; })[0];
      if (t) {
        this.taskId = t.id;
        this.setData({
          isNew: false,
          form: {
            title: t.title || '', note: t.note || '', dept: t.dept || '',
            status: t.status || '待开始', assigned: t.assigned || '', due: t.due || ''
          },
          statusIndex: Math.max(0, store.STATUS_LIST.indexOf(t.status)),
          attachments: (t.attachments || []).map(function(a){ a.sizeText = sizeText(a.size); return a; })
        });
        wx.setNavigationBarTitle({ title: '编辑事项' });
        return;
      }
    }
    wx.setNavigationBarTitle({ title: '新增事项' });
  },

  onInput: function (e) {
    var f = e.currentTarget.dataset.field;
    var form = this.data.form;
    form[f] = e.detail.value;
    this.setData({ form: form });
  },

  onStatus: function (e) {
    var i = +e.detail.value;
    var form = this.data.form;
    form.status = store.STATUS_LIST[i];
    this.setData({ statusIndex: i, form: form });
  },

  onDate: function (e) {
    var f = e.currentTarget.dataset.field;
    var form = this.data.form;
    form[f] = e.detail.value;
    this.setData({ form: form });
  },

  clearDate: function (e) {
    var f = e.currentTarget.dataset.field;
    var form = this.data.form;
    form[f] = '';
    this.setData({ form: form });
  },

  onPaste: function (e) {
    this.setData({ pasteText: e.detail.value });
  },

  parsePaste: function () {
    var text = (this.data.pasteText || '').trim();
    if (!text) {
      wx.showToast({ title: '先把通知文字粘进来', icon: 'none' });
      return;
    }
    var list = P.parseMulti(text);
    if (list.length >= 2) {
      var drafts = list.map(function (m) {
        return {
          title: m.title, note: m.note, dept: m.dept, status: m.status || '待开始',
          assigned: m.assigned, due: m.due,
          meta: [m.dept, m.due ? '截止 ' + m.due : '', m.status || '待开始'].filter(Boolean).join(' · ')
        };
      });
      this.setData({ multiDraft: drafts });
      wx.showToast({ title: '识别到 ' + drafts.length + ' 条', icon: 'none' });
      return;
    }
    var r = list[0];
    var form = this.data.form;
    if (r.title) form.title = r.title;
    if (r.dept) form.dept = r.dept;
    if (r.status) form.status = r.status;
    if (r.assigned) form.assigned = r.assigned;
    if (r.due) form.due = r.due;
    this.setData({
      form: form,
      statusIndex: Math.max(0, store.STATUS_LIST.indexOf(form.status))
    });
    wx.showToast({ title: '已按文字填好，可再改', icon: 'none' });
  },

  removeDraft: function (e) {
    var i = +e.currentTarget.dataset.index;
    var drafts = this.data.multiDraft.slice();
    drafts.splice(i, 1);
    this.setData({ multiDraft: drafts });
  },

  cancelMulti: function () {
    this.setData({ multiDraft: [] });
  },

  addAllDrafts: function () {
    var drafts = this.data.multiDraft;
    if (!drafts.length) return;
    var list = store.getTasks();
    var now = new Date().toISOString();
    drafts.forEach(function (m) {
      list.push({
        id: store.uid(), title: m.title, note: m.note || '', dept: m.dept || '',
        status: m.status || '待开始', assigned: m.assigned || '', due: m.due || '',
        attachments: [], createdAt: now, updatedAt: now
      });
    });
    store.saveTasks(list);
    var n = drafts.length;
    this.setData({ multiDraft: [], pasteText: '' });
    wx.showToast({ title: '已加入 ' + n + ' 条', icon: 'success' });
    setTimeout(function () { wx.navigateBack(); }, 350);
  },

  addImage: function () {
    var self = this;
    wx.chooseMedia({
      count: 6,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        var files = res.tempFiles.map(function (f) { return { path: f.tempFilePath, name: '图片_' + Date.now() + '.jpg', size: f.size, type: 'image' }; });
        self.saveFiles(files);
      }
    });
  },

  chooseFiles: function () {
    var self = this;
    wx.chooseMessageFile({
      count: 5,
      type: 'file',
      success: function (res) {
        var files = res.tempFiles.map(function (f) {
          return { path: f.path, name: f.name, size: f.size, type: /\.(jpg|jpeg|png|gif|webp)$/i.test(f.name) ? 'image' : 'file' };
        });
        self.saveFiles(files);
      }
    });
  },

  saveFiles: function (files) {
    var self = this;
    var list = this.data.attachments.slice();
    var pending = files.length;
    if (!pending) return;
    files.forEach(function (f) {
      wx.saveFile({
        tempFilePath: f.path,
        success: function (r) {
          list.push({ id: store.uid(), name: f.name, size: f.size, sizeText: sizeText(f.size), type: f.type, path: r.savedFilePath });
        },
        fail: function () {
          list.push({ id: store.uid(), name: f.name, size: f.size, sizeText: sizeText(f.size), type: f.type, path: f.path });
        },
        complete: function () {
          pending--;
          if (pending === 0) self.setData({ attachments: list });
        }
      });
    });
  },

  openAttachment: function (e) {
    var a = this.data.attachments[+e.currentTarget.dataset.index];
    if (!a || !a.path) return;
    if (a.type === 'image') {
      wx.previewImage({ urls: [a.path], current: a.path });
    } else {
      wx.openDocument({ filePath: a.path, showMenu: true, fail: function () { wx.showToast({ title: '无法打开该文件', icon: 'none' }); } });
    }
  },

  removeAttachment: function (e) {
    var i = +e.currentTarget.dataset.index;
    var list = this.data.attachments.slice();
    var a = list[i];
    list.splice(i, 1);
    this.setData({ attachments: list });
    if (a && a.path) { try { wx.removeSavedFile({ filePath: a.path }); } catch (err) {} }
  },

  save: function () {
    if (this.data.saving) return;
    this.setData({ saving: true });
    var f = this.data.form;
    var list = store.getTasks();
    var now = new Date().toISOString();
    var task = {
      title: (f.title || '').trim(),
      note: (f.note || '').trim(),
      dept: (f.dept || '').trim(),
      status: f.status || '待开始',
      assigned: f.assigned || '',
      due: f.due || '',
      attachments: this.data.attachments,
      updatedAt: now
    };
    if (this.taskId) {
      var idx = list.findIndex(function (x) { return x.id === this.taskId; }.bind(this));
      if (idx > -1) {
        task.id = this.taskId;
        task.createdAt = list[idx].createdAt || now;
        list[idx] = task;
      } else list.push(task);
    } else {
      task.id = store.uid();
      task.createdAt = now;
      list.push(task);
    }
    var ok = store.saveTasks(list);
    this.setData({ saving: false });
    if (ok) {
      wx.showToast({ title: '已保存', icon: 'success' });
      setTimeout(function () { wx.navigateBack(); }, 350);
    }
  },

  remove: function () {
    var self = this;
    if (!this.taskId) { wx.navigateBack(); return; }
    wx.showModal({
      title: '删除这条事项？',
      content: '删除后本机不再保留，附件也一并移除。',
      confirmColor: '#A95F45',
      success: function (res) {
        if (!res.confirm) return;
        store.markDeleted(self.taskId);
        var list = store.getTasks().filter(function (x) { return x.id !== self.taskId; });
        store.saveTasks(list);
        wx.navigateBack();
      }
    });
  }
});

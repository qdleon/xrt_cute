var store = require('../../utils/store');
var D = require('../../utils/date');
var cloud = require('../../utils/cloud');

var STATUS_CLASS = {
  '待开始': 'st-start',
  '进行中': 'st-doing',
  '暂缓': 'st-pause',
  '已完成': 'st-done'
};
var WEEK_CN = ['日', '一', '二', '三', '四', '五', '六'];

function periodRange(period, ref) {
  if (period === 'all') return null;
  var start, end;
  if (period === 'week') {
    var off = (ref.getDay() + 6) % 7;
    start = D.addDays(ref, -off);
    end = D.addDays(start, 6);
  } else if (period === 'month') {
    start = new Date(ref.getFullYear(), ref.getMonth(), 1);
    end = new Date(ref.getFullYear(), ref.getMonth() + 1, 0);
  } else {
    start = new Date(ref.getFullYear(), 0, 1);
    end = new Date(ref.getFullYear(), 11, 31);
  }
  start.setHours(0, 0, 0, 0);
  end.setHours(0, 0, 0, 0);
  return { start: start, end: end };
}

Page({
  data: {
    todayLabel: '',
    weekLabel: '',
    summary: '',
    cloudOn: false,
    cloudText: '本机存储',
    stats: { open: 0, due: 0, week: 0, done: 0 },
    tab: 'list',
    period: 'all',
    rangeLabel: '全部事项',
    showRangeNav: false,
    items: [],
    total: 0,
    keyword: '',
    filters: [
      { key: 'all', label: '全部' },
      { key: 'pending', label: '待办中' },
      { key: 'due', label: '已逾期' },
      { key: 'done', label: '已完成' }
    ],
    activeFilter: 'all',
    calTitle: '',
    calCount: '',
    cells: [],
    selDate: '',
    selLabel: '',
    selAssigned: [],
    selDue: [],
    selMark: ''
  },

  onLoad: function () {
    var now = new Date();
    this.refDate = D.today0();
    this.calMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    this.selDate = D.ymd(now);
    this.setData({
      todayLabel: now.getFullYear() + ' 年 ' + (now.getMonth() + 1) + ' 月 ' + now.getDate() + ' 日',
      weekLabel: '星期' + WEEK_CN[now.getDay()]
    });
  },

  onShow: function () {
    this.refresh();
    this.cloudSync(true);
  },

  cloudSync: function (silent) {
    var self = this;
    if (!cloud.init()) {
      this.setData({ cloudOn: false, cloudText: '本机存储' });
      if (!silent) wx.showToast({ title: '未配置云开发，数据只在本机', icon: 'none' });
      return;
    }
    var now = Date.now();
    if (this._lastSync && now - this._lastSync < 8000) return;
    this._lastSync = now;
    var localDoc = { tasks: store.getTasks(), marks: store.getMarks(), tombstones: store.getTombs() };
    cloud.pull().then(function (remote) {
      var merged = cloud.mergeDocs(localDoc, remote || {});
      store.saveTasks(merged.tasks);
      store.saveMarks(merged.marks);
      store.saveTombs(merged.tombstones);
      self.refresh();
      return cloud.push(merged);
    }).then(function () {
      self.setData({ cloudOn: true, cloudText: '云同步' });
      if (!silent) wx.showToast({ title: '已同步', icon: 'success' });
    }).catch(function () {
      self.setData({ cloudOn: false, cloudText: '本机存储' });
      if (!silent) wx.showToast({ title: '同步失败，本机数据不受影响', icon: 'none' });
    });
  },

  manualSync: function () {
    this._lastSync = 0;
    this.cloudSync(false);
  },

  refresh: function () {
    this.tasks = store.getTasks();
    this.marks = store.getMarks();
    this.computeStats();
    this.computeList();
    this.buildCalendar();
  },

  computeStats: function () {
    var open = 0, due = 0, week = 0, done = 0;
    this.tasks.forEach(function (t) {
      var st = store.stateOf(t);
      if (t.status === '已完成') { done++; return; }
      if (t.status !== '暂缓') open++;
      if (st.key === 'due') due++;
      if (st.key === 'due' || st.key === 'soon') week++;
    });
    var summary = '今天没有到期事项';
    if (due > 0) summary = '有 ' + due + ' 条已经逾期，先处理它们';
    else if (week > 0) summary = '7 天内还有 ' + week + ' 条要交';
    else if (open > 0) summary = '手上还有 ' + open + ' 条待办';
    else if (done > 0) summary = '全部办完了';
    this.setData({ stats: { open: open, due: due, week: week, done: done }, summary: summary });
  },

  computeList: function () {
    var self = this;
    var r = periodRange(this.data.period, this.refDate);
    var kw = this.data.keyword.trim().toLowerCase();
    var filter = this.data.activeFilter;

    var list = this.tasks.filter(function (t) {
      if (filter === 'done' && t.status !== '已完成') return false;
      if (filter === 'pending' && t.status === '已完成') return false;
      if (filter === 'due' && store.stateOf(t).key !== 'due') return false;
      if (r) {
        var key = t.due || t.assigned;
        if (!key) return false;
        var d = D.parseYmd(key);
        if (!d || d < r.start || d > r.end) return false;
      }
      if (kw) {
        var blob = (t.title + ' ' + (t.note || '') + ' ' + (t.dept || '')).toLowerCase();
        if (blob.indexOf(kw) < 0) return false;
      }
      return true;
    });

    var view = list.map(function (t) {
      var st = store.stateOf(t);
      var isDone = t.status === '已完成';
      return {
        id: t.id,
        title: t.title || '（未命名事项）',
        note: t.note || '',
        dept: t.dept || '—',
        assigned: t.assigned ? '下达 ' + D.fmtDate(t.assigned) : '',
        due: t.due ? D.fmtDate(t.due) : '—',
        status: t.status,
        statusClass: STATUS_CLASS[t.status] || 'st-start',
        stateKey: isDone ? 'done' : st.key,
        dueLabel: isDone ? '' : st.label,
        dueClass: 'badge-' + st.key,
        attachCount: (t.attachments || []).length
      };
    });

    view.sort(function (a, b) {
      if ((a.status === '已完成') !== (b.status === '已完成')) return a.status === '已完成' ? 1 : -1;
      if (a.due === '—') return 1;
      if (b.due === '—') return -1;
      return a.due < b.due ? -1 : a.due > b.due ? 1 : 0;
    });

    this.setData({
      items: view,
      total: list.length,
      rangeLabel: this.rangeText(),
      showRangeNav: this.data.period !== 'all'
    });
  },

  rangeText: function () {
    var r = periodRange(this.data.period, this.refDate);
    if (!r) return '全部事项';
    if (this.data.period === 'week') return D.fmtMD(D.ymd(r.start)) + ' – ' + D.fmtMD(D.ymd(r.end));
    if (this.data.period === 'month') return r.start.getFullYear() + ' 年 ' + (r.start.getMonth() + 1) + ' 月';
    return r.start.getFullYear() + ' 年';
  },

  setTab: function (e) {
    var tab = e.currentTarget.dataset.tab;
    this.setData({ tab: tab });
    if (tab === 'cal') this.buildCalendar();
  },

  setPeriod: function (e) {
    this.refDate = D.today0();
    this.setData({ period: e.currentTarget.dataset.period });
    this.computeList();
  },

  shiftPeriod: function (e) {
    var dir = +e.currentTarget.dataset.dir;
    var p = this.data.period;
    if (p === 'week') this.refDate = D.addDays(this.refDate, dir * 7);
    else if (p === 'month') this.refDate = new Date(this.refDate.getFullYear(), this.refDate.getMonth() + dir, 1);
    else this.refDate = new Date(this.refDate.getFullYear() + dir, 0, 1);
    this.computeList();
  },

  setFilter: function (e) {
    this.setData({ activeFilter: e.currentTarget.dataset.key });
    this.computeList();
  },

  onSearch: function (e) {
    this.setData({ keyword: e.detail.value });
    this.computeList();
  },

  goNew: function () {
    wx.navigateTo({ url: '/pages/edit/edit' });
  },

  goEdit: function (e) {
    wx.navigateTo({ url: '/pages/edit/edit?id=' + e.currentTarget.dataset.id });
  },

  buildCalendar: function () {
    var self = this;
    var y = this.calMonth.getFullYear(), m = this.calMonth.getMonth();
    var first = new Date(y, m, 1);
    var off = (first.getDay() + 6) % 7;
    var start = D.addDays(first, -off);
    var todayStr = D.ymd(D.today0());
    var cells = [];
    var count = 0;

    for (var i = 0; i < 42; i++) {
      var d = D.addDays(start, i);
      var ds = D.ymd(d);
      var a = 0, du = 0;
      this.tasks.forEach(function (t) {
        if (t.assigned === ds) a++;
        if (t.due === ds) du++;
        if (t.assigned === ds || t.due === ds) count++;
      });
      cells.push({
        date: ds,
        day: d.getDate(),
        out: d.getMonth() !== m,
        today: ds === todayStr,
        sel: ds === this.selDate,
        a: a,
        d: du,
        mark: this.marks[ds] ? this.marks[ds].slice(0, 4) : ''
      });
    }
    if (!cells.filter(function (c) { return c.sel; }).length) {
      var firstIn = cells.filter(function (c) { return !c.out; })[0];
      if (firstIn) {
        this.selDate = firstIn.date;
        this.buildCalendar();
        return;
      }
    }
    this.setData({
      calTitle: y + ' 年 ' + (m + 1) + ' 月',
      calCount: count ? '本月 ' + this.uniqCount() + ' 条' : '本月无事项',
      cells: cells
    });
    this.buildDayPanel();
  },

  uniqCount: function () {
    var r = { start: new Date(this.calMonth.getFullYear(), this.calMonth.getMonth(), 1), end: new Date(this.calMonth.getFullYear(), this.calMonth.getMonth() + 1, 0) };
    return this.tasks.filter(function (t) {
      var keys = [t.assigned, t.due];
      return keys.some(function (k) {
        var d = D.parseYmd(k);
        return d && d >= r.start && d <= r.end;
      });
    }).length;
  },

  buildDayPanel: function () {
    var ds = this.selDate;
    var assigned = [], due = [];
    this.tasks.forEach(function (t) {
      if (t.assigned === ds) assigned.push({ id: t.id, title: t.title || '（未命名事项）', status: t.status });
      if (t.due === ds) due.push({ id: t.id, title: t.title || '（未命名事项）', status: t.status });
    });
    this.setData({
      selDate: ds,
      selLabel: D.fmtMD(ds) + ' · 星期' + WEEK_CN[new Date(ds.replace(/-/g, '/')).getDay()],
      selAssigned: assigned,
      selDue: due,
      selMark: this.marks[ds] || ''
    });
  },

  prevMonth: function () {
    this.calMonth = new Date(this.calMonth.getFullYear(), this.calMonth.getMonth() - 1, 1);
    this.buildCalendar();
  },
  nextMonth: function () {
    this.calMonth = new Date(this.calMonth.getFullYear(), this.calMonth.getMonth() + 1, 1);
    this.buildCalendar();
  },
  backToday: function () {
    var now = new Date();
    this.calMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    this.selDate = D.ymd(now);
    this.buildCalendar();
  },

  tapDay: function (e) {
    this.selDate = e.currentTarget.dataset.date;
    this.buildCalendar();
  },

  editMark: function () {
    var self = this;
    var ds = this.selDate;
    wx.showModal({
      title: '给 ' + D.fmtMD(ds) + ' 加个标记',
      editable: true,
      placeholderText: '例如：系务会、外出调研',
      content: this.marks[ds] || '',
      confirmText: '保存',
      success: function (res) {
        if (!res.confirm) return;
        var v = (res.content || '').trim().slice(0, 12);
        var marks = store.getMarks();
        if (v) marks[ds] = v;
        else delete marks[ds];
        store.saveMarks(marks);
        self.marks = marks;
        self.buildCalendar();
        self._lastSync = 0;
        self.cloudSync(true);
      }
    });
  }
});

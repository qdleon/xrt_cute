/**
 * 微信云开发同步（比 Gitee 省事：不用令牌、不用建仓库、不用配域名）
 *
 * 使用前：
 * 1. 开发者工具 → 云开发 → 开通，记下环境 ID，填到下面 CLOUD_ENV；
 * 2. 云开发数据库 → 新建集合 `ledger`，权限选「仅创建者可读写」；
 * 3. 重新编译，首页会显示「云同步」。
 *
 * 数据按微信账号（openid）自动归属，换手机登录同一微信即可接上；
 * 没配置或调用失败时自动退回本机存储，不影响页面使用。
 */
var CLOUD_ENV = '';
var COLLECTION = 'ledger';
var inited = false;
var enabled = false;

function configured() {
  return !!CLOUD_ENV && typeof wx !== 'undefined' && !!wx.cloud;
}

function init() {
  if (!configured()) return false;
  if (inited) return enabled;
  try {
    wx.cloud.init({ env: CLOUD_ENV, traceUser: true });
    enabled = true;
  } catch (e) {
    enabled = false;
  }
  inited = true;
  return enabled;
}

function db() { return wx.cloud.database(); }

function pull() {
  if (!init()) return Promise.reject(new Error('未配置云开发'));
  return db().collection(COLLECTION).limit(1).get().then(function (res) {
    return (res.data && res.data[0]) || null;
  });
}

function push(doc) {
  if (!init()) return Promise.reject(new Error('未配置云开发'));
  var coll = db().collection(COLLECTION);
  var payload = {
    tasks: doc.tasks || [],
    marks: doc.marks || {},
    tombstones: doc.tombstones || {},
    updatedAt: new Date().toISOString()
  };
  return coll.limit(1).get().then(function (res) {
    var cur = res.data && res.data[0];
    if (cur) return coll.doc(cur._id).set({ data: payload });
    return coll.add({ data: payload });
  });
}

function taskTime(t) {
  return (t && (t.updatedAt || t.createdAt)) || '';
}

function mergeDocs(local, remote) {
  local = local || {};
  remote = remote || {};
  var map = {};
  var tombs = {};
  var lt = local.tombstones || {}, rt = remote.tombstones || {};
  Object.keys(lt).forEach(function (k) { tombs[k] = lt[k]; });
  Object.keys(rt).forEach(function (k) {
    if (!tombs[k] || rt[k] > tombs[k]) tombs[k] = rt[k];
  });

  function take(list) {
    (list || []).forEach(function (t) {
      if (!t || !t.id) return;
      var prev = map[t.id];
      if (!prev || taskTime(t) >= taskTime(prev)) map[t.id] = t;
    });
  }
  take(local.tasks);
  take(remote.tasks);

  var tasks = Object.keys(map).map(function (k) { return map[k]; }).filter(function (t) {
    var gone = tombs[t.id];
    return !gone || gone < taskTime(t);
  });

  var marks = {};
  Object.keys(remote.marks || {}).forEach(function (k) { marks[k] = remote.marks[k]; });
  Object.keys(local.marks || {}).forEach(function (k) { marks[k] = local.marks[k]; });

  return { tasks: tasks, marks: marks, tombstones: tombs };
}

module.exports = {
  configured: configured,
  init: init,
  pull: pull,
  push: push,
  mergeDocs: mergeDocs
};

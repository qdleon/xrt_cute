function pad(n) { return n < 10 ? '0' + n : '' + n; }
function ymd(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
function today0() { var d = new Date(); d.setHours(0, 0, 0, 0); return d; }
function parseYmd(s) {
  if (!s) return null;
  var m = String(s).match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return null;
  var d = new Date(+m[1], +m[2] - 1, +m[3]);
  d.setHours(0, 0, 0, 0);
  return isNaN(d.getTime()) ? null : d;
}
function addDays(d, n) { var x = new Date(+d); x.setDate(x.getDate() + n); x.setHours(0, 0, 0, 0); return x; }
function diffDays(a, b) { return Math.round((a - b) / 86400000); }
function fmtDate(s) { return s ? String(s).replace(/-/g, '.') : ''; }
function fmtMD(s) {
  var d = parseYmd(s);
  return d ? (d.getMonth() + 1) + '月' + d.getDate() + '日' : '';
}
function cnNum(str) {
  var map = { 一: 1, 二: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9, 十: 10 };
  if (/^\d+$/.test(str)) return +str;
  if (str === '十') return 10;
  if (/^十[一二三四五六七八九]$/.test(str)) return 10 + map[str[1]];
  if (/^[一二三四五六七八九]十$/.test(str)) return map[str[0]] * 10;
  if (/^[一二三四五六七八九]十[一二三四五六七八九]$/.test(str)) return map[str[0]] * 10 + map[str[2]];
  return map[str[0]] || 0;
}
module.exports = {
  pad: pad, ymd: ymd, today0: today0, parseYmd: parseYmd,
  addDays: addDays, diffDays: diffDays, fmtDate: fmtDate, fmtMD: fmtMD, cnNum: cnNum
};

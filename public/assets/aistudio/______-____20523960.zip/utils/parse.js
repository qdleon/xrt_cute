var D = require('./date');

var DEPT_WORDS = ['教务处', '学生处', '人事处', '财务处', '科研处', '科技处', '党政办公室', '党委办公室', '校办', '办公室', '组织部', '宣传部', '统战部', '团委', '工会', '国际合作处', '国际交流处', '研究生院', '后勤保障处', '后勤处', '资产处', '实验室管理处', '图书馆', '档案馆', '信息化中心', '网络中心', '招生办', '就业指导中心', '评估中心', '督导组', '学院', '系办公室', '教研室', '系办', '院办'];

function extractDates(text) {
  var now = D.today0();
  var out = [];
  function push(d, idx) { if (d) out.push({ date: D.ymd(d), index: idx }); }
  var m;
  var reA = /(20\d{2})\s*[年\-\/.]\s*(\d{1,2})\s*[月\-\/.]\s*(\d{1,2})\s*[日号]?/g;
  while ((m = reA.exec(text))) {
    var d = new Date(+m[1], +m[2] - 1, +m[3]);
    d.setHours(0, 0, 0, 0);
    if (!isNaN(d.getTime())) push(d, m.index);
  }
  var reB = /([0-9]{1,2}|[一二三四五六七八九十]{1,3})\s*月\s*([0-9]{1,2}|[一二三四五六七八九十]{1,3})\s*[日号]?/g;
  while ((m = reB.exec(text))) {
    var mo = D.cnNum(m[1]), da = D.cnNum(m[2]);
    if (mo >= 1 && mo <= 12 && da >= 1 && da <= 31) {
      var y = now.getFullYear();
      var dd = new Date(y, mo - 1, da);
      dd.setHours(0, 0, 0, 0);
      if (D.diffDays(dd, now) < -60) dd.setFullYear(y + 1);
      push(dd, m.index);
    }
  }
  var reC = /(?:^|[^\d])(\d{1,2})\s*[\/.]\s*(\d{1,2})(?!\d)/g;
  while ((m = reC.exec(text))) {
    var ctx = text.slice(Math.max(0, m.index - 12), Math.min(text.length, m.index + m[0].length + 10));
    if (/截止|之前|前完成|提交|上报|报送|节点/.test(ctx)) {
      var mo2 = +m[1], da2 = +m[2];
      if (mo2 >= 1 && mo2 <= 12 && da2 >= 1 && da2 <= 31) {
        var d2 = new Date(now.getFullYear(), mo2 - 1, da2);
        d2.setHours(0, 0, 0, 0);
        if (D.diffDays(d2, now) < -60) d2.setFullYear(now.getFullYear() + 1);
        push(d2, m.index);
      }
    }
  }
  var weekMap = { 日: 0, 天: 0, 一: 1, 二: 2, 三: 3, 四: 4, 五: 5, 六: 6 };
  var reD = /(今天|今日|明天|明日|后天|大后天|本周[一二三四五六日天]|这周[一二三四五六日天]|下周[一二三四五六日天]|下个月?\s*\d{1,2}\s*[日号]|本月底|月底|下月初)/g;
  while ((m = reD.exec(text))) {
    var w = m[1], d3 = null;
    if (w === '今天' || w === '今日') d3 = new Date(now);
    else if (w === '明天' || w === '明日') d3 = D.addDays(now, 1);
    else if (w === '后天') d3 = D.addDays(now, 2);
    else if (w === '大后天') d3 = D.addDays(now, 3);
    else if (/^(本周|这周)[一二三四五六日天]/.test(w)) d3 = D.addDays(now, weekMap[w.slice(2)] - now.getDay());
    else if (/^下周[一二三四五六日天]/.test(w)) d3 = D.addDays(now, (7 - now.getDay()) + weekMap[w.slice(2)]);
    else if (/^下个月?\s*\d{1,2}/.test(w)) d3 = new Date(now.getFullYear(), now.getMonth() + 1, D.cnNum(w.replace(/[^\d]/g, '')) || 1);
    else if (w === '本月底' || w === '月底') d3 = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    else if (w === '下月初') d3 = new Date(now.getFullYear(), now.getMonth() + 1, 5);
    if (d3) push(d3, m.index);
  }
  var seen = {};
  return out.filter(function (o) {
    var k = o.index + '|' + o.date;
    if (seen[k]) return false;
    seen[k] = 1;
    return true;
  }).sort(function (a, b) { return a.index - b.index; });
}

function pickDept(text) {
  var m = text.match(/(?:对接(?:部门)?|承办(?:部门)?|责任部门|牵头部门|主办部门|负责部门|所属部门|部门)\s*[：:\-]?\s*([^\n，。；;、]{2,22})/);
  if (m) {
    var v = m[1].replace(/^[\s「『"']+|[\s」』"']+$/g, '').trim();
    if (v.length <= 22) return v;
  }
  for (var i = 0; i < DEPT_WORDS.length; i++) {
    if (text.indexOf(DEPT_WORDS[i]) > -1) return DEPT_WORDS[i];
  }
  var m2 = text.match(/[\u4e00-\u9fa5]{2,10}(?:处|部|科|中心|办公室|学院|馆|委)(?![\u4e00-\u9fa5])/);
  return m2 ? m2[0] : '';
}

function cleanTitle(s) {
  var t = String(s)
    .replace(/【[^】]*】/g, '')
    .replace(/^(各位|尊敬的)?(老师|同事|领导|同学)(们)?[：:，,、\s]*/, '')
    .replace(/^(通知|温馨提示|提醒|工作通知|紧急通知)[：:\s]*/, '')
    .replace(/^[\s\-—·•*]+|[\s。；;,，、]+$/g, '')
    .trim();
  t = t.replace(/^(请)?\s*(于|在|至)?\s*(?:20\d{2}\s*[年\-\/.]\s*\d{1,2}\s*[月\-\/.]\s*\d{1,2}\s*[日号]?|\d{1,2}\s*月\s*\d{1,2}\s*[日号]?|本周[一二三四五六日天]|下周[一二三四五六日天]|今天|明天|后天|月底)\s*(之前|以前|前)?\s*/, '');
  t = t.replace(/^(请|须|需要?|务必)\s*/, '').replace(/^(将|把|对)\s*/, '').trim();
  var cut = t.split(/[，,。；;：:]/)[0].trim();
  if (cut.length >= 6) t = cut;
  if (t.length > 60) t = t.slice(0, 60) + '…';
  return t;
}

var ACTION_RE = /(提交|完成|报送|上报|统计|收集|整理|核对|安排|组织|参加|准备|填报|审核|检查|落实|办理|推进|开展|召开|编写|制定|修订|更新|维护|录入|发放|领取|采购|维修|清理|联系|确认|反馈|汇总|归档|上传|下载|发布|培训|评审|申报|申请|验收|整改|调研|接待|布置)/;

function summarizeTitle(src) {
  var t = String(src || '').replace(/\r/g, '');
  t = t.replace(/(?:请|于|在)?\s*(?:20\d{2}\s*[年\-\/.]\s*)?(?:\d{1,2}\s*[月\-\/.]\s*\d{1,2}\s*[日号]?|本周[一二三四五六日天]|下周[一二三四五六日天]|今天|今日|明天|明日|后天|月底|本月底|下月初)\s*(?:之前|以前|前)?/g, ' ');
  t = t.replace(/（[^）]*）/g, '').replace(/\([^)]*\)/g, '');
  t = t.replace(/^(?:通知|温馨提示|提醒|工作通知|紧急通知)[：:\s]*/, '');
  t = t.replace(/^(?:各位|尊敬的)?(?:老师|同事|领导|同学|各单位|各部门)(?:们)?[：:，,、\s]*/, '');
  t = t.replace(/^(?:请|须|需|务必)\s*/, '');
  t = t.replace(/^各[\u4e00-\u9fa5]{0,6}(?:教研室|处|科|部门|学院|系|中心|单位|年级|班级)\s*/, '');
  var delivered = false;
  var m = t.match(/[，,]\s*(?:交|报送|上报|提交|发|送)(?:至|给)?/);
  if (m) {
    t = t.slice(0, m.index);
    delivered = true;
  } else {
    var m2 = t.match(/(?:交|报送|上报|提交|发|送)(?:至|给)?[^，,。；\n]*$/);
    if (m2 && m2.index > 2) {
      t = t.slice(0, m2.index);
      delivered = true;
    }
  }
  t = t.replace(/[，,]?(?:一式|加盖|原件|复印件)[^，,。；\n]*$/, '');
  t = t.replace(/^(?:请|须|需|务必|将|把|对)\s*/, '');
  t = t.replace(/[，,、。；\s]+$/, '');
  var am = t.match(ACTION_RE);
  if (am && am.index > 0 && am.index <= 16 && !/^(?:检查|审核|统计|汇总|安排|整理|收集|核对)(?:材料|表|单|工作|情况|记录|报告|意见|数据)/.test(t.slice(am.index))) {
    t = t.slice(am.index);
  }
  t = t.trim();
  if (delivered && !ACTION_RE.test(t.slice(0, 6))) t = '提交' + t;
  t = t.split(/[，,。；;\n]/)[0].trim();
  if (t.length > 26) t = t.slice(0, 24) + '…';
  return t;
}

function parseText(raw) {
  var text = String(raw || '').replace(/\r/g, '');
  var norm = text.replace(/[０-９]/g, function (c) { return String.fromCharCode(c.charCodeAt(0) - 65248); });
  var res = { title: '', assigned: '', due: '', dept: '', status: '', note: '' };
  var dates = extractDates(norm);
  var dueHit = null, assignedHit = null, undecided = [];

  dates.forEach(function (d) {
    var lead = norm.slice(Math.max(0, d.index - 12), d.index);
    var tail = norm.slice(d.index, d.index + 18);
    var tailDue = /(?:之前|以前|前|截止|截至|前完成|前提交|前报送)/.test(tail);
    if (tailDue || /截止|完成时间|完成日期|办理时限|截至|之前|前完成|上报|提交|报送/.test(lead)) {
      if (!dueHit) dueHit = d;
    } else if (/下达|下发|通知日期|发文|布置|开始|自/.test(lead)) {
      if (!assignedHit) assignedHit = d;
    } else {
      undecided.push(d);
    }
  });
  if (!dueHit && undecided.length) {
    if (undecided.length >= 2) {
      if (!assignedHit) assignedHit = undecided[0];
      dueHit = undecided[undecided.length - 1];
    } else {
      dueHit = undecided[0];
    }
  }
  if (assignedHit && dueHit && (assignedHit.index === dueHit.index || assignedHit.date === dueHit.date)) assignedHit = null;

  var mDue = norm.match(/(?:截止日期|截止时间|截止|完成时间|完成日期|办理时限)\s*[：:\-]?\s*([^\n，。；;]{2,26})/);
  if (mDue && extractDates(mDue[1]).length) dueHit = extractDates(mDue[1])[0];
  var mAss = norm.match(/(?:下达日期|下达时间|发文日期|通知日期|布置日期|收到日期)\s*[：:\-]?\s*([^\n，。；;]{2,26})/);
  if (mAss && extractDates(mAss[1]).length) assignedHit = extractDates(mAss[1])[0];

  res.due = dueHit ? dueHit.date : '';
  res.assigned = assignedHit ? assignedHit.date : '';

  var mTitle = norm.match(/(?:具体事项|事项|任务|工作内容|内容|主题|标题)\s*[：:]\s*([^\n]{2,120})/);
  if (mTitle) res.title = cleanTitle(mTitle[1]);
  res.dept = pickDept(norm);

  if (!res.title) {
    var lines = norm.split(/\n+/).map(function (s) { return s.trim(); }).filter(function (s) { return s.length >= 4; });
    var best = '';
    for (var i = 0; i < lines.length; i++) {
      var cleaned = cleanTitle(lines[i]);
      if (cleaned.length < 4) continue;
      if (/(截止|对接|部门|备注|联系人)/.test(cleaned) && cleaned.length < 18) continue;
      if (/提交|完成|准备|报送|参加|组织|整理|核对|落实|填报|上报|审核|检查|收集|统计|安排|办理|会议|培训|材料/.test(cleaned)) {
        best = cleaned;
        break;
      }
      if (!best && cleaned.length >= 8) best = cleaned;
    }
    if (!best && lines.length) best = cleanTitle(lines[0]);
    res.title = best || '';
  }

  var clauses = norm.split(/[\n。；;，,]/).map(function (s) { return s.trim(); }).filter(Boolean);
  var noteLines = clauses.filter(function (s) {
    if (s.length < 4) return false;
    if (res.title && (s.indexOf(res.title) > -1 || res.title.indexOf(s) > -1)) return false;
    return /(备注|注意|要求|需|请|联系人|材料|清单|携带|提交|盖章|签字|一式|原件|复印件|邮箱|电话)/.test(s);
  }).map(function (s) {
    return s.replace(/^(对接(部门)?|承办(部门)?|责任部门)[：:\s]*/, '');
  }).filter(function (s) { return s.length >= 3; });
  res.note = '';

  if (/(已完成|已提交|已办结|已落实|已上报|已反馈)/.test(norm)) res.status = '已完成';
  else if (/(暂缓|搁置|延期|暂停)/.test(norm)) res.status = '暂缓';
  else if (/(进行中|正在|推进中|处理中|待反馈|待审核|待回复)/.test(norm)) res.status = '进行中';
  else if (/(未开始|待开始|待启动|待安排)/.test(norm)) res.status = '待开始';

  res.title = summarizeTitle(res.title || norm);
  if (!res.assigned) res.assigned = D.ymd(new Date());
  return res;
}

function splitCandidates(raw) {
  var norm = String(raw || '').replace(/\r/g, '').replace(/[０-９]/g, function (c) { return String.fromCharCode(c.charCodeAt(0) - 65248); });
  var lines = norm.split('\n').map(function (s) { return s.trim(); }).filter(Boolean);
  var numbered = [], cur = null;
  lines.forEach(function (line) {
    var m = line.match(/^(?:[（(]?(\d{1,2})[.、)）]|[一二三四五六七八九十]+、|[-•·*])\s*(.+)$/);
    if (m) { if (cur) numbered.push(cur); cur = m[2]; }
    else if (cur) { cur += '\n' + line; }
    else { numbered.push(line); }
  });
  if (cur) numbered.push(cur);
  if (numbered.length >= 2) return numbered;
  var blocks = norm.split(/\n\s*\n/).map(function (s) { return s.trim(); }).filter(Boolean);
  if (blocks.length >= 2) return blocks;
  return [norm];
}

function parseMulti(raw) {
  var base = parseText(raw);
  var segs = splitCandidates(raw).filter(function (s) { return s.length >= 4; });
  if (segs.length < 2) return [base];
  var out = [];
  segs.forEach(function (seg) {
    var r = parseText(seg);
    if (!r.title) return;
    if (!r.due && base.due) r.due = base.due;
    if (!r.assigned && base.assigned) r.assigned = base.assigned;
    if (!r.dept && base.dept) r.dept = base.dept;
    if (out.some(function (x) { return x.title === r.title; })) return;
    out.push(r);
  });
  return out.length >= 2 ? out : [base];
}

module.exports = { parseText: parseText, parseMulti: parseMulti, extractDates: extractDates };

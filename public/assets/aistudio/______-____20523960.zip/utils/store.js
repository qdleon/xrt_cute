var KEY = 'task-ledger.v1';
var MARK_KEY = 'task-ledger.marks.v1';
var TOMB_KEY = 'task-ledger.tomb.v1';
var STATUS_LIST = ['待开始', '进行中', '暂缓', '已完成'];

function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

function normalizeStatus(t) {
  if (STATUS_LIST.indexOf(t.status) > -1) return t.status;
  if (t.status === 'done' || t.status === '已完成') return '已完成';
  if (t.progress === 100) return '已完成';
  if (Number(t.progress) > 0) return '进行中';
  return '待开始';
}

function getTasks() {
  var list = [];
  try { list = wx.getStorageSync(KEY) || []; } catch (e) { list = []; }
  if (!Array.isArray(list)) list = [];
  return list.map(function (t) {
    t.id = t.id || uid();
    t.attachments = Array.isArray(t.attachments) ? t.attachments : [];
    t.status = normalizeStatus(t);
    delete t.progress;
    return t;
  });
}
function saveTasks(list) {
  try { wx.setStorageSync(KEY, list); return true; } catch (e) {
    wx.showToast({ title: '保存失败，存储空间不足', icon: 'none' });
    return false;
  }
}
function getMarks() {
  try { return wx.getStorageSync(MARK_KEY) || {}; } catch (e) { return {}; }
}
function saveMarks(m) {
  try { wx.setStorageSync(MARK_KEY, m); } catch (e) {}
}
function getTombs() {
  try { return wx.getStorageSync(TOMB_KEY) || {}; } catch (e) { return {}; }
}
function saveTombs(t) {
  try { wx.setStorageSync(TOMB_KEY, t); } catch (e) {}
}
function markDeleted(id) {
  var t = getTombs();
  t[id] = new Date().toISOString();
  saveTombs(t);
}
function stateOf(t) {
  if (t.status === '已完成') return { key: 'done', label: '已完成', days: null };
  if (t.status === '暂缓') return { key: 'paused', label: '暂缓', days: null };
  var d = t.due ? new Date(t.due.replace(/-/g, '/')) : null;
  if (!d) return { key: 'none', label: '未设截止', days: null };
  var today = new Date(); today.setHours(0, 0, 0, 0);
  d.setHours(0, 0, 0, 0);
  var days = Math.round((d - today) / 86400000);
  if (days < 0) return { key: 'due', label: '逾期 ' + Math.abs(days) + ' 天', days: days };
  if (days === 0) return { key: 'soon', label: '今天到期', days: 0 };
  if (days <= 7) return { key: 'soon', label: '还剩 ' + days + ' 天', days: days };
  return { key: 'later', label: '还剩 ' + days + ' 天', days: days };
}
module.exports = {
  KEY: KEY, MARK_KEY: MARK_KEY, STATUS_LIST: STATUS_LIST,
  uid: uid, normalizeStatus: normalizeStatus,
  getTasks: getTasks, saveTasks: saveTasks, getMarks: getMarks, saveMarks: saveMarks,
  getTombs: getTombs, saveTombs: saveTombs, markDeleted: markDeleted,
  stateOf: stateOf
};
